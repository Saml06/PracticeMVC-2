﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SamTestDemo.Data;
using SamTestDemo.Models;

namespace SamTestDemo.Controllers
{
    public class CreditsCardsController : Controller
    {
        private readonly SamTestDemoContext _context;

        public CreditsCardsController(SamTestDemoContext context)
        {
            _context = context;
        }

        // GET: CreditsCards
        public async Task<IActionResult> Index()
        {
              return _context.CreditsCard != null ? 
                          View(await _context.CreditsCard.ToListAsync()) :
                          Problem("Entity set 'SamTestDemoContext.CreditsCard'  is null.");
        }

        // GET: CreditsCards/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.CreditsCard == null)
            {
                return NotFound();
            }

            var creditsCard = await _context.CreditsCard
                .FirstOrDefaultAsync(m => m.Id == id);
            if (creditsCard == null)
            {
                return NotFound();
            }

            return View(creditsCard);
        }

        // GET: CreditsCards/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: CreditsCards/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Name,Description,Credits,Total")] CreditsCard creditsCard)
        {
            if (ModelState.IsValid)
            {
                _context.Add(creditsCard);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(creditsCard);
        }

        // GET: CreditsCards/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.CreditsCard == null)
            {
                return NotFound();
            }

            var creditsCard = await _context.CreditsCard.FindAsync(id);
            if (creditsCard == null)
            {
                return NotFound();
            }
            return View(creditsCard);
        }

        // POST: CreditsCards/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,Description,Credits,Total")] CreditsCard creditsCard)
        {
            if (id != creditsCard.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(creditsCard);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CreditsCardExists(creditsCard.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(creditsCard);
        }

        // GET: CreditsCards/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.CreditsCard == null)
            {
                return NotFound();
            }

            var creditsCard = await _context.CreditsCard
                .FirstOrDefaultAsync(m => m.Id == id);
            if (creditsCard == null)
            {
                return NotFound();
            }

            return View(creditsCard);
        }

        // POST: CreditsCards/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.CreditsCard == null)
            {
                return Problem("Entity set 'SamTestDemoContext.CreditsCard'  is null.");
            }
            var creditsCard = await _context.CreditsCard.FindAsync(id);
            if (creditsCard != null)
            {
                _context.CreditsCard.Remove(creditsCard);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CreditsCardExists(int id)
        {
          return (_context.CreditsCard?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
