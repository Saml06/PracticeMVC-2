﻿namespace SamTestDemo.Models
{
    public class CreditsCard
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public int Credits { get; set; }
        public int Total { get; set; }
    }
    
}
