﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using SamTestDemo.Data;
using SamTestDemo.Migrations;
using System;
using System.Linq;

namespace SamTestDemo.Models;

public static class SeedData
{
    public static void Initialize(IServiceProvider serviceProvider)
    {
        using (var context = new SamTestDemoContext(serviceProvider.GetRequiredService<DbContextOptions<SamTestDemoContext>>()))
        {
            // Look for any movies.
            if (context.FoodItems.Any())
            {
                return;   // DB has been seeded
            }
            context.FoodItems.AddRange(
                new FoodItems
                {
                    FoodName = "Burger",
                    Stock = 5,
                    Price = 7.99M,
                }
            );
            context.SaveChanges();
        }
    }
}