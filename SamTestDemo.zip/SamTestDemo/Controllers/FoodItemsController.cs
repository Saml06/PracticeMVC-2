﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SamTestDemo.Data;
using SamTestDemo.Models;

namespace SamTestDemo.Controllers
{
    public class FoodItemsController : Controller
    {
        private readonly SamTestDemoContext _context;

        public FoodItemsController(SamTestDemoContext context)
        {
            _context = context;
        }

        // GET: FoodItems
        public async Task<IActionResult> Index()
        {
              return _context.FoodItems != null ? 
                          View(await _context.FoodItems.ToListAsync()) :
                          Problem("Entity set 'SamTestDemoContext.FoodItems'  is null.");
        }

        // GET: FoodItems/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.FoodItems == null)
            {
                return NotFound();
            }

            var foodItems = await _context.FoodItems
                .FirstOrDefaultAsync(m => m.Id == id);
            if (foodItems == null)
            {
                return NotFound();
            }

            return View(foodItems);
        }

        // GET: FoodItems/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: FoodItems/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,FoodName,Stock,Price")] FoodItems foodItems)
        {
            if (ModelState.IsValid)
            {
                _context.Add(foodItems);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(foodItems);
        }

        // GET: FoodItems/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.FoodItems == null)
            {
                return NotFound();
            }

            var foodItems = await _context.FoodItems.FindAsync(id);
            if (foodItems == null)
            {
                return NotFound();
            }
            return View(foodItems);
        }

        // POST: FoodItems/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,FoodName,Stock,Price")] FoodItems foodItems)
        {
            if (id != foodItems.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(foodItems);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!FoodItemsExists(foodItems.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(foodItems);
        }

        // GET: FoodItems/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.FoodItems == null)
            {
                return NotFound();
            }

            var foodItems = await _context.FoodItems
                .FirstOrDefaultAsync(m => m.Id == id);
            if (foodItems == null)
            {
                return NotFound();
            }

            return View(foodItems);
        }

        // POST: FoodItems/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.FoodItems == null)
            {
                return Problem("Entity set 'SamTestDemoContext.FoodItems'  is null.");
            }
            var foodItems = await _context.FoodItems.FindAsync(id);
            if (foodItems != null)
            {
                _context.FoodItems.Remove(foodItems);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool FoodItemsExists(int id)
        {
          return (_context.FoodItems?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
