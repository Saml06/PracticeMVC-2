﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using SamTestDemo.Models;

namespace SamTestDemo.Data
{
    public class SamTestDemoContext : DbContext
    {
        public SamTestDemoContext (DbContextOptions<SamTestDemoContext> options)
            : base(options)
        {
        }

        public DbSet<SamTestDemo.Models.FoodItems> FoodItems { get; set; } = default!;

        public DbSet<SamTestDemo.Models.CreditsCard> CreditsCard { get; set; } = default!;
    }
}
